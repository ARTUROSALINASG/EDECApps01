<?php
// test_list_documents.php: Script de prueba para listar documentos de un usuario y devolver JSON.
// Este script es para depuración y no debe usarse en producción sin validaciones adicionales.

// ***** INICIO: LÍNEAS AÑADIDAS PARA DEPURACIÓN DE ERRORES *****
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ***** FIN: LÍNEAS AÑADIDAS PARA DEPURACIÓN DE ERRORES *****

// Incluye el archivo de configuración de la base de datos.
// Esto hará que la variable $conn (la conexión MySQLi) esté disponible.
require_once 'config.php';

// Establece la cabecera para indicar que la respuesta será JSON.
header('Content-Type: application/json');

// Inicializa un array para la respuesta.
$response = [
    'success' => false,
    'data' => [],
    'message' => ''
];

try {
    // Verifica si la conexión a la base de datos es válida.
    if (!$conn || $conn->connect_error) {
        http_response_code(500);
        throw new Exception('Error de conexión a la base de datos: ' . ($conn->connect_error ?? 'Desconocido'));
    }

    // Obtiene el usuario de la URL. Para esta prueba, usaremos un usuario de ejemplo.
    // En tu aplicación real, esto vendría de $_GET['usuario'].
    $usuario_prueba = isset($_GET['usuario']) ? $_GET['usuario'] : 'Usuario01'; // Cambia 'Usuario01' por un usuario real que tenga documentos

    // Prepara la consulta SQL para obtener los documentos del usuario.
    $stmt = $conn->prepare('SELECT id, nombre_original, nombre_archivo, fecha, permiso, ruta FROM documentos WHERE usuario = ? ORDER BY fecha DESC');

    if ($stmt === false) {
        throw new Exception('Error al preparar la consulta SQL: ' . $conn->error);
    }

    // Vincula el parámetro 'usuario' a la sentencia.
    $stmt->bind_param('s', $usuario_prueba);

    // Ejecuta la sentencia.
    $stmt->execute();

    // ***** INICIO: CAMBIO PARA NO USAR get_result() *****
    // Vincula las columnas de resultado a variables PHP
    $stmt->bind_result($id, $nombre_original, $nombre_archivo, $fecha, $permiso, $ruta);

    // Recorre los resultados fila por fila
    while ($stmt->fetch()) {
        $response['data'][] = [
            'id' => $id,
            'nombre_original' => $nombre_original,
            'nombre_archivo' => $nombre_archivo,
            'fecha' => $fecha,
            'permiso' => $permiso,
            'ruta' => $ruta
        ];
    }
    // ***** FIN: CAMBIO PARA NO USAR get_result() *****

    if (count($response['data']) > 0) { // Verifica si se encontraron documentos
        $response['success'] = true;
        $response['message'] = 'Documentos obtenidos exitosamente.';
    } else {
        $response['success'] = true;
        $response['message'] = 'No se encontraron documentos para el usuario ' . $usuario_prueba . '.';
    }

} catch (Exception $e) {
    // Captura cualquier excepción o error y prepara una respuesta de error.
    $response['success'] = false;
    $response['message'] = 'Error en el servidor: ' . $e->getMessage();
    // Registra el error en los logs del servidor para depuración.
    error_log("Error en test_list_documents.php: " . $e->getMessage());
} finally {
    // Cierra la sentencia preparada si existe.
    if (isset($stmt) && $stmt !== false) {
        $stmt->close();
    }
    // Cierra la conexión a la base de datos.
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

// Devuelve la respuesta final como JSON.
echo json_encode($response);

?>
