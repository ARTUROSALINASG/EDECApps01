<?php
header('Content-Type: application/json');

require_once 'config.php';

$response = ['success' => false, 'error' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        throw new Exception('Método no permitido. Se espera una solicitud POST.');
    }

    if (!$conn || $conn->connect_error) {
        http_response_code(500);
        throw new Exception('Error de conexión a la base de datos.');
    }

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $usuario = isset($_POST['usuario']) ? trim($_POST['usuario']) : '';

    if (!$id || empty($usuario)) {
        http_response_code(400);
        throw new Exception('Faltan datos requeridos (ID de documento o usuario).');
    }

    $stmt_select = $conn->prepare('SELECT ruta FROM documentos WHERE id = ? AND usuario = ?');
    if ($stmt_select === false) {
        throw new Exception('Error al preparar la consulta de selección: ' . $conn->error);
    }
    $stmt_select->bind_param('is', $id, $usuario);
    $stmt_select->execute();

    // --- CAMBIO AQUÍ: Usando bind_result() y fetch() en lugar de get_result() ---
    $ruta = null; // Variable para almacenar la ruta
    $stmt_select->bind_result($ruta);
    $document_found = $stmt_select->fetch(); // Intenta obtener la fila
    $stmt_select->close();

    $file_path_to_delete = null;
    if ($document_found && $ruta) { // Verifica si se encontró el documento y tiene ruta
        $file_path_to_delete = __DIR__ . '/' . $ruta;
    } else {
        // Si el documento no se encontró o no tiene ruta, no podemos borrarlo
        http_response_code(404); // Not Found
        throw new Exception('Documento no encontrado o ruta no válida.');
    }
    // --- FIN DEL CAMBIO ---

    $stmt_delete = $conn->prepare('DELETE FROM documentos WHERE id = ? AND usuario = ?');
    if ($stmt_delete === false) {
        throw new Exception('Error al preparar la consulta de eliminación: ' . $conn->error);
    }
    $stmt_delete->bind_param('is', $id, $usuario);
    $ok = $stmt_delete->execute();
    $stmt_delete->close();

    if ($ok) {
        if ($file_path_to_delete && file_exists($file_path_to_delete)) {
            if (!unlink($file_path_to_delete)) {
                error_log("Advertencia: No se pudo eliminar el archivo físico: " . $file_path_to_delete);
            }
        }
        $response['success'] = true;
        $response['message'] = 'Documento eliminado exitosamente.';
    } else {
        http_response_code(500);
        throw new Exception('No se pudo borrar el documento de la base de datos: ' . $conn->error);
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['error'] = $e->getMessage();
    error_log("Error en delete_document.php: " . $e->getMessage());
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);

?>
