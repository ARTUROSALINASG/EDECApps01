<?php
// save_summary.php: Guarda el resumen y la información del documento en la base de datos
header('Content-Type: application/json');

// Incluye el archivo de configuración de la base de datos.
// Esto hará que la variable $conn (la conexión MySQLi) esté disponible.
require_once 'config.php';

// Verifica que la solicitud sea de tipo POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Método no permitido
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

// Obtiene y sanitiza los datos de la solicitud POST
$usuario = isset($_POST['usuario']) ? trim($_POST['usuario']) : 'anonimo';
$nombre_archivo_original = isset($_POST['nombre_archivo']) ? $_POST['nombre_archivo'] : null; // Renombrado para claridad
$resumen = isset($_POST['resumen']) ? trim($_POST['resumen']) : '';

// Validar datos mínimos
if (!$usuario || !$nombre_archivo_original || !$resumen) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'error' => 'Faltan datos requeridos (usuario, nombre de archivo o resumen).']);
    exit;
}

// Generar nombre de archivo único para guardar en el servidor
// Usar el mismo nombre para nombre_original y nombre_archivo_original para la DB
$nombre_original_db = $nombre_archivo_original;

// Configurar la zona horaria para la fecha y hora
// Esto es importante para asegurar que las fechas se guarden correctamente.
date_default_timezone_set('America/Mexico_City');
$fecha = date('Y-m-d H:i:s');

// Generar un nombre de archivo único para el resumen guardado en el servidor
$nombre_base = pathinfo($nombre_archivo_original, PATHINFO_FILENAME);
$nombre_archivo_servidor = $nombre_base . '_' . $usuario . '_' . date('Ymd_His') . '_resumen.txt';
$ruta_servidor = 'documentos/' . $nombre_archivo_servidor;

// Permiso por defecto
$permiso = 'privado';

// Guardar el resumen como archivo físico en la carpeta documentos/
$carpeta = __DIR__ . '/documentos/';
if (!is_dir($carpeta)) {
    // Si la carpeta no existe, intenta crearla.
    // Los permisos 0755 son más seguros que 0777.
    if (!mkdir($carpeta, 0755, true)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'No se pudo crear la carpeta de documentos.']);
        exit;
    }
}

// Intenta guardar el contenido del resumen en el archivo
if (file_put_contents($carpeta . $nombre_archivo_servidor, $resumen) === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'No se pudo guardar el archivo del resumen en el servidor.']);
    exit;
}

// Conexión a la base de datos.
// La variable $conn ya está disponible y conectada desde config.php
if (!$conn || $conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error de conexión a la base de datos.']);
    exit;
}

// Preparar y ejecutar la consulta INSERT
$stmt = $conn->prepare("INSERT INTO documentos (nombre_archivo, nombre_original, usuario, fecha, permiso, ruta, resumen) VALUES (?, ?, ?, ?, ?, ?, ?)");

if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error al preparar la consulta SQL: ' . $conn->error]);
    exit;
}

// Vincula los parámetros a la sentencia preparada
// 'sssssss' indica que todos los parámetros son strings
$stmt->bind_param('sssssss', $nombre_archivo_servidor, $nombre_original_db, $usuario, $fecha, $permiso, $ruta_servidor, $resumen);

// Ejecuta la sentencia
$ok = $stmt->execute();

if ($ok) {
    echo json_encode(['success' => true, 'message' => 'Resumen guardado exitosamente.']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'No se pudo guardar el resumen en la base de datos: ' . $stmt->error]);
}

// Cierra la sentencia y la conexión a la base de datos
$stmt->close();
$conn->close();

?>
