<?php
$dbConfig = [
    'host' => 'localhost',
    'user' => 'edecalunomytiend_analisis01',
    'pass' => 'EdecMongterrey#$',
    'db'   => 'edecalunomytiend_analisis_inteligentev02',
    'charset' => 'utf8mb4'
];

$conn = new mysqli(
    $dbConfig['host'],
    $dbConfig['user'],
    $dbConfig['pass'],
    $dbConfig['db']
);

if ($conn->connect_error) {
    die("Error de conexi��n a la base de datos: " . $conn->connect_error);
}

if (isset($dbConfig['charset'])) {
    $conn->set_charset($dbConfig['charset']);
}
?>
