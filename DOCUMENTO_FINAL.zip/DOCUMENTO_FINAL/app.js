// Botón Cambiar usuario
const changeUserBtn = document.getElementById('changeUserBtn');
if (changeUserBtn) {
    changeUserBtn.addEventListener('click', function() {
        // Limpiar usuario y volver al login
        loggedUser = null;
        loginUser.value = '';
        loginPass.value = '';
        welcomeScreen.classList.add('hidden');
        loginContainer.classList.remove('hidden');
        document.getElementById('mainContainer').classList.add('hidden');
        userDocsSection.classList.add('hidden');
        if (backToWelcomeBtn) backToWelcomeBtn.classList.add('hidden');
    });
}
// Funciones para mostrar/ocultar el botón Pantalla Principal
function showBackToWelcomeBtn() {
    if (backToWelcomeBtn) backToWelcomeBtn.classList.remove('hidden');
}
function hideBackToWelcomeBtn() {
    if (backToWelcomeBtn) backToWelcomeBtn.classList.add('hidden');
}
// Botón para volver a la pantalla principal desde documentos
const backToWelcomeBtn = document.getElementById('backToWelcomeBtn');
if (backToWelcomeBtn) {
    backToWelcomeBtn.classList.add('hidden'); // Oculto por defecto
    backToWelcomeBtn.addEventListener('click', function() {
        userDocsSection.classList.add('hidden');
        welcomeScreen.classList.remove('hidden');
        document.getElementById('mainContainer').classList.add('hidden');
        backToWelcomeBtn.classList.add('hidden');
    });
}
// app.js: Lógica JS extraída de index.html

// Autenticación simple
const loginContainer = document.getElementById('loginContainer');
const loginForm = document.getElementById('loginForm');
const loginUser = document.getElementById('loginUser');
const loginPass = document.getElementById('loginPass');
const loginError = document.getElementById('loginError');
const welcomeScreen = document.getElementById('welcomeScreen');
const welcomeUserName = document.getElementById('welcomeUserName');
const goToDocsBtn = document.getElementById('goToDocsBtn');
const goToResumenBtn = document.getElementById('goToResumenBtn');

const USERS = [
    { username: 'Usuario01', password: 'abc1234' },
    { username: 'Usuario02', password: 'abc1234' }
];

loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const user = loginUser.value.trim();
    const pass = loginPass.value;
    const found = USERS.find(u => u.username === user && u.password === pass);
    if (found) {
        loginError.classList.add('hidden');
        loginContainer.classList.add('hidden');
        welcomeScreen.classList.remove('hidden');
        loggedUser = user;
        if (welcomeUserName) {
            welcomeUserName.textContent = loggedUser;
        }
        // Ocultar otras vistas
        document.getElementById('mainContainer').classList.add('hidden');
        userDocsSection.classList.add('hidden');
        // Asegurar que el botón Pantalla Principal esté oculto
        if (backToWelcomeBtn) backToWelcomeBtn.classList.add('hidden');
    } else {
        loginError.textContent = 'Usuario o contraseña incorrectos.';
        loginError.classList.remove('hidden');
    }
});

// Navegación desde la pantalla de bienvenida
if (goToResumenBtn) {
    goToResumenBtn.addEventListener('click', function() {
        welcomeScreen.classList.add('hidden');
        document.getElementById('mainContainer').classList.remove('hidden');
        userDocsSection.classList.add('hidden');
        showBackToWelcomeBtn();
    });
}

// Función para cargar documentos del usuario
async function loadUserDocuments() {
    if (!loggedUser) return;
    docsList.innerHTML = '';
    try {
        const resp = await fetch('list_documents.php?usuario=' + encodeURIComponent(loggedUser));
        const data = await resp.json();
        if (!data.success) throw new Error(data.error || 'Error al consultar documentos');
        
        if (data.data.length === 0) {
            docsList.innerHTML = '<div class="text-blue-500">No tienes documentos guardados.</div>';
        } else {
            data.data.forEach(doc => {
                const item = document.createElement('div');
                item.className = 'p-3 bg-gray-800 rounded-lg flex flex-col md:flex-row md:items-center md:justify-between';
                item.innerHTML = `
                    <span class='font-semibold text-blue-200'>${doc.nombre_original}</span>
                    <span class='text-xs text-gray-400 ml-2'>${doc.fecha}</span>
                    <span class='text-xs text-green-400 ml-2'>${doc.permiso}</span>
                    <a href='documentos/${doc.nombre_archivo}' download class='ml-2 text-blue-400 underline'>Descargar</a>
                    <button class='ml-2 px-2 py-1 rounded bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition deleteDocBtn' data-id='${doc.id}'>Borrar</button>
                `;
                docsList.appendChild(item);
            });
            // Botones de borrar individuales
            document.querySelectorAll('.deleteDocBtn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    const id = btn.getAttribute('data-id');
                    
                    // Reemplazando confirm() con un console.log para depuración
                    console.log('Solicitud de confirmación de borrado para ID:', id);
                    const confirmed = true; // Simula confirmación para avanzar en la depuración

                    if (!confirmed) return; 

                    btn.disabled = true;
                    btn.textContent = 'Borrando...';
                    try {
                        const resp = await fetch('delete_document.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: `id=${encodeURIComponent(id)}&usuario=${encodeURIComponent(loggedUser)}`
                        });
                        const data = await resp.json();
                        if (data.success) {
                            btn.parentElement.remove();
                        } else {
                            // Reemplazando alert() con showMessage() y console.error()
                            showMessage('Error: ' + (data.error || 'No se pudo borrar.'), 'error');
                            console.error('Error al borrar documento:', data.error || 'No se pudo borrar.');
                        }
                    } catch (err) {
                        // Reemplazando alert() con showMessage() y console.error()
                        showMessage('Error: ' + err.message, 'error');
                        console.error('Error al borrar documento (catch):', err.message);
                    }
                });
            });
        }
    } catch (err) {
        docsList.innerHTML = '<div class="text-red-400">' + err.message + '</div>';
    }
}

if (goToDocsBtn) {
    goToDocsBtn.addEventListener('click', function() {
        welcomeScreen.classList.add('hidden');
        userDocsSection.classList.remove('hidden');
        document.getElementById('mainContainer').classList.add('hidden');
        loadUserDocuments();
        showBackToWelcomeBtn();
    });
}
// Mostrar el botón también al mostrar el generador o el resumen generado
const mainContainer = document.getElementById('mainContainer');
const summaryOutput = document.getElementById('summaryOutput');

if (mainContainer) {
    // Cuando se muestra el generador
    const observer = new MutationObserver(() => {
        if (!mainContainer.classList.contains('hidden')) {
            showBackToWelcomeBtn();
        }
    });
    observer.observe(mainContainer, { attributes: true, attributeFilter: ['class'] });
}
if (summaryOutput) {
    // Cuando se muestra el resumen generado
    const observer2 = new MutationObserver(() => {
        if (!summaryOutput.classList.contains('hidden')) {
            showBackToWelcomeBtn();
        }
    });
    observer2.observe(summaryOutput, { attributes: true, attributeFilter: ['class'] });
}

// pdf.js worker
if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

// Obtener referencias a los elementos del DOM
const fileInput = document.getElementById('fileInput');
const customFileButton = document.getElementById('customFileButton');
const customFileButtonText = document.getElementById('customFileButtonText');
const selectedFileName = document.getElementById('selectedFileName');
const summarizeButton = document.getElementById('summarizeButton');
const buttonText = document.getElementById('buttonText');
const loadingSpinner = document.getElementById('loadingSpinner');
const messageBox = document.getElementById('messageBox');
const summaryText = document.getElementById('summaryText');
const downloadWordButton = document.getElementById('downloadWordButton');
const userDocsSection = document.getElementById('userDocsSection');
const showDocsBtn = document.getElementById('showDocsBtn');
const docsList = document.getElementById('docsList');

let selectedFile = null;
let loggedUser = null;

// Función para mostrar mensajes al usuario
function showMessage(message, type = 'info') {
    messageBox.textContent = message;
    messageBox.classList.remove('hidden', 'bg-red-100', 'text-red-700', 'bg-green-100', 'text-green-700', 'bg-blue-100', 'text-blue-700');
    if (type === 'error') {
        messageBox.classList.add('bg-red-100', 'text-red-700');
    } else if (type === 'success') {
        messageBox.classList.add('bg-green-100', 'text-green-700');
    } else {
        messageBox.classList.add('bg-blue-100', 'text-blue-700');
    }
    messageBox.classList.remove('hidden');
}
function hideMessage() {
    messageBox.classList.add('hidden');
}

function updateFileInputAnimation() {
    if (!fileInput.files || fileInput.files.length === 0) {
        customFileButton.classList.add('file-animate');
        selectedFileName.textContent = '';
        customFileButtonText.textContent = 'Selecciona Documento';
    } else {
        customFileButton.classList.remove('file-animate');
        if (fileInput.files[0]) {
            selectedFileName.textContent = fileInput.files[0].name;
            customFileButtonText.textContent = 'Cambiar Documento';
        }
    }
}
updateFileInputAnimation();
customFileButton.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (event) => {
    selectedFile = event.target.files[0];
    updateFileInputAnimation();
    if (selectedFile) {
        summarizeButton.disabled = false;
        summarizeButton.classList.remove('btn-disabled');
        summarizeButton.classList.add('btn-primary');
        summarizeButton.classList.remove('bg-gradient-to-r', 'from-green-300', 'via-blue-300', 'to-red-300', 'from-yellow-300', 'via-green-300', 'to-blue-300', 'text-gray-900', 'ring-2', 'ring-yellow-200');
        summarizeButton.classList.add('bg-gradient-to-r', 'from-cyan-300', 'via-green-200', 'to-blue-200', 'text-gray-900', 'shadow-md', 'border-2', 'border-cyan-200');
        summarizeButton.style.fontWeight = 'bold';
        summarizeButton.style.letterSpacing = '1px';
        summarizeButton.style.fontSize = '1.35rem';
        hideMessage();
        summaryOutput.classList.add('hidden');
        summaryText.textContent = '';
        mainContainer.classList.remove('max-w-2xl');
        mainContainer.classList.add('max-w-md');
        document.getElementById('downloadWordButton').style.display = 'none';
        document.getElementById('downloadOptions').style.display = 'none';
        summarizeButton.style.display = 'flex';
        summarizeButton.classList.remove('hidden', 'invisible');
        summarizeButton.classList.remove(
            'bg-gradient-to-r',
            'from-green-300', 'via-blue-300', 'to-red-300',
            'from-yellow-300', 'via-green-300', 'to-blue-300',
            'ring-2', 'ring-yellow-200',
            'text-gray-900', 'shadow-md', 'border-2', 'border-cyan-200'
        );
        summarizeButton.classList.add(
            'bg-gradient-to-r', 'from-cyan-300', 'via-green-200', 'to-blue-200',
            'text-gray-900', 'shadow-md', 'border-2', 'border-cyan-200'
        );
        summarizeButton.style.fontWeight = 'bold';
        summarizeButton.style.letterSpacing = '1px';
        summarizeButton.style.fontSize = '1.35rem';
        document.getElementById('downloadWordButton').style.display = 'none';
        document.getElementById('downloadOptions').style.display = 'none';
    } else {
        summarizeButton.disabled = true;
        summarizeButton.classList.add('btn-disabled');
        summarizeButton.classList.remove('btn-primary');
        summarizeButton.classList.remove('bg-gradient-to-r', 'from-cyan-300', 'via-green-200', 'to-blue-200', 'text-gray-900', 'shadow-md', 'border-2', 'border-cyan-200');
        summarizeButton.classList.remove('bg-gradient-to-r', 'from-yellow-300', 'via-green-300', 'to-blue-300', 'ring-2', 'ring-yellow-200');
        summarizeButton.classList.add('bg-gradient-to-r', 'from-green-300', 'via-blue-300', 'to-red-300');
        summarizeButton.style.fontWeight = '';
        summarizeButton.style.letterSpacing = '1px';
        summarizeButton.style.fontSize = '1.35rem';
        showMessage('Por favor, selecciona un archivo.', 'info');
        document.getElementById('downloadWordButton').style.display = 'none';
        document.getElementById('downloadOptions').style.display = 'none';
    }
});

async function extractTextFromPdf(file) {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    let fullText = '';
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map(item => item.str).join(' ');
        fullText += pageText + ' ';
    }
    return fullText;
}

function readTextFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (e) => reject(e);
        reader.readAsText(file);
    });
}

async function callGeminiApi(prompt, retries = 3, delay = 1000) {
    let chatHistory = [];
    chatHistory.push({ role: "user", parts: [{ text: prompt }] });
    const payload = { contents: chatHistory };
    const apiKey = "AIzaSyAN8hhzj9E7QOI1ykZ5FQwqYkPhKd95TzA";
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${apiKey}`;
    for (let i = 0; i < retries; i++) {
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                if (response.status === 429 && i < retries - 1) {
                    await new Promise(res => setTimeout(res, delay));
                    delay *= 2;
                    continue;
                }
                throw new Error(`Error HTTP! estado: ${response.status}`);
            }
            const result = await response.json();
            if (result.candidates && result.candidates.length > 0 &&
                result.candidates[0].content && result.candidates[0].content.parts &&
                result.candidates[0].content.parts.length > 0) {
                return result.candidates[0].content.parts[0].text;
            } else {
                throw new Error('Respuesta inesperada de la API de Gemini.');
            }
        } catch (error) {
            if (i === retries - 1) {
                throw error;
            }
            await new Promise(res => setTimeout(res, delay));
            delay *= 2;
        }
    }
    throw new Error('Fallo al llamar a la API de Gemini después de varios reintentos.');
}

summarizeButton.addEventListener('click', async () => {
    if (!selectedFile) {
        showMessage('Por favor, selecciona un archivo primero.', 'error');
        return;
    }
    if (!loggedUser) {
        showMessage('No se detectó usuario autenticado. Por favor, inicia sesión de nuevo.', 'error');
        return;
    }
    summarizeButton.disabled = true;
    summarizeButton.classList.add('btn-disabled');
    summarizeButton.classList.remove('btn-primary');
    buttonText.textContent = 'Resumiendo...';
    loadingSpinner.classList.remove('hidden');
    hideMessage();
    summaryOutput.classList.add('hidden');
    summaryText.textContent = '';
    mainContainer.classList.remove('max-w-2xl');
    mainContainer.classList.add('max-w-md');
    document.getElementById('downloadWordButton').style.display = 'none';
    const customQuestionInput = document.getElementById('customQuestion');
    const customQuestion = customQuestionInput && customQuestionInput.value.trim() !== '' ? customQuestionInput.value.trim() : null;
    let documentContent = '';
    try {
        if (selectedFile.type === 'text/plain') {
            documentContent = await readTextFile(selectedFile);
        } else if (selectedFile.type === 'application/pdf') {
            showMessage('Extrayendo texto del PDF, esto puede tardar un momento...', 'info');
            documentContent = await extractTextFromPdf(selectedFile);
        } else {
            throw new Error('Tipo de archivo no soportado. Por favor, sube un archivo .txt o .pdf.');
        }
        if (documentContent.trim().length === 0) {
            throw new Error('El documento está vacío o no se pudo extraer texto.');
        }
        const maxInputLength = 20000;
        const textToSummarize = documentContent.length > maxInputLength
            ? documentContent.substring(0, maxInputLength) + "\n\n[Texto truncado para el resumen. El documento original es más largo.]"
            : documentContent;
        let prompt = `Por favor, resume el siguiente documento de forma concisa y clara. Al final, agrega una sección titulada 'Puntos clave' con una lista de los aspectos más importantes del documento. Además, extrae y presenta explícitamente los nombres, fechas y lugares relevantes que se mencionen en el texto, si los hay. En la sección de Nombres, agrega una breve descripción del rol o relevancia de cada nombre dentro del documento.`;
        if (customQuestion) {
            prompt += `\n\nPregunta personalizada: ${customQuestion}\nPor favor, responde a la pregunta anterior de forma clara y breve en una sección titulada 'Respuesta a la pregunta personalizada'.`;
        }
        prompt += `\n\n${textToSummarize}`;
        const summary = await callGeminiApi(prompt);
        summaryText.textContent = summary;
        // Guardar el resumen y la información del documento en el backend
        let saveResult = null;
        try {
            const formData = new FormData();
            formData.append('usuario', loggedUser);
            formData.append('nombre_archivo', selectedFile ? selectedFile.name : '');
            formData.append('resumen', summary);
            const resp = await fetch('save_summary.php', {
                method: 'POST',
                body: formData
            });
            saveResult = await resp.json();
        } catch (e) {
            saveResult = { success: false, error: 'No se pudo guardar el resumen en el servidor.' };
        }
        if (customQuestion) {
            setTimeout(() => {
                summaryOutput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 300);
        }
        summaryOutput.classList.remove('hidden');
        if (saveResult && saveResult.success) {
            showMessage('Resumen generado exitosamente y documento guardado.', 'success');
        } else {
            showMessage('Resumen generado, pero no se pudo guardar en el servidor: ' + (saveResult && saveResult.error ? saveResult.error : ''), 'error');
        }
        if (summary && summary.trim().length > 0) {
            document.getElementById('downloadWordButton').style.display = 'block';
            document.getElementById('downloadOptions').style.display = 'flex';
            summarizeButton.style.display = 'none';
        } else {
            document.getElementById('downloadWordButton').style.display = 'none';
            document.getElementById('downloadOptions').style.display = 'none';
            summarizeButton.style.display = '';
        }
        mainContainer.classList.remove('max-w-md');
        mainContainer.classList.add('max-w-4xl');
    } catch (error) {
        document.getElementById('downloadWordButton').style.display = 'none';
        document.getElementById('downloadOptions').style.display = 'none';
        mainContainer.classList.remove('max-w-4xl');
        mainContainer.classList.add('max-w-md');
        summarizeButton.style.display = '';
        console.error('Error al resumir el documento:', error);
        showMessage(`Error: ${error.message}. Asegúrate de que el archivo no esté vacío y que tienes conexión a internet.`, 'error');
    } finally {
        summarizeButton.disabled = false;
        summarizeButton.classList.remove('btn-disabled');
        summarizeButton.classList.add('btn-primary');
        buttonText.textContent = 'Resumir Documento';
        loadingSpinner.classList.add('hidden');
    }
});

downloadWordButton.addEventListener('click', async function() {
    const resumen = summaryText.textContent;
    if (!resumen || resumen.trim().length === 0) return;
    let format = document.getElementById('fileFormatSelect').value;
    let blob, ext, mime;
    let fileName = 'resumen';
    if (format === 'doc') {
        const header = `<!DOCTYPE html>\n<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns=\"http://www.w3.org/TR/REC-html40\"><head><meta charset='utf-8'><title>Resumen</title></head><body>`;
        const footer = '</body></html>';
        const html = header + '<h2>Resumen generado</h2><p>' + resumen.replace(/\n/g, '<br>') + '</p>' + footer;
        mime = 'application/msword';
        ext = 'doc';
        blob = new Blob([html], { type: mime });
    } else {
        mime = 'text/plain';
        ext = 'txt';
        blob = new Blob([resumen], { type: mime });
    }
    if (window.showSaveFilePicker) {
        try {
            const handle = await window.showSaveFilePicker({
                suggestedName: fileName + '.' + ext,
                types: [
                    { description: 'Word', accept: { 'application/msword': ['.doc'] } },
                    { description: 'Texto', accept: { 'text/plain': ['.txt'] } }
                ]
            });
            const writable = await handle.createWritable();
            await writable.write(blob);
            await writable.close();
        } catch (e) {}
    } else {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName + '.' + ext;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 100);
    }
});

if (showDocsBtn) {
    showDocsBtn.addEventListener('click', async () => {
        if (!loggedUser) {
            showMessage('Debes iniciar sesión para ver tus documentos.', 'error');
            return;
        }
        showDocsBtn.disabled = true;
        showDocsBtn.textContent = 'Cargando...';
        docsList.innerHTML = '';
        try {
            const resp = await fetch('list_documents.php?usuario=' + encodeURIComponent(loggedUser));
            const data = await resp.json();
            if (!data.success) throw new Error(data.error || 'Error al consultar documentos');
            
            if (data.data.length === 0) {
                docsList.innerHTML = '<div class="text-blue-500">No tienes documentos guardados.</div>';
            } else {
                data.data.forEach(doc => {
                    const item = document.createElement('div');
                    item.className = 'p-3 bg-gray-800 rounded-lg flex flex-col md:flex-row md:items-center md:justify-between';
                    item.innerHTML = `
                        <span class='font-semibold text-blue-200'>${doc.nombre_original}</span>
                        <span class='text-xs text-gray-400 ml-2'>${doc.fecha}</span>
                        <span class='text-xs text-green-400 ml-2'>${doc.permiso}</span>
                        <a href='documentos/${doc.nombre_archivo}' download class='ml-2 text-blue-400 underline'>Descargar</a>
                        <button class='ml-2 px-2 py-1 rounded bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition deleteDocBtn' data-id='${doc.id}'>Borrar</button>
                    `;
                    docsList.appendChild(item);
                });

                document.querySelectorAll('.deleteDocBtn').forEach(btn => {
                    btn.addEventListener('click', async (e) => {
                        const id = btn.getAttribute('data-id');
                        
                        // Reemplazando confirm() con un console.log para depuración
                        console.log('Solicitud de confirmación de borrado para ID:', id);
                        const confirmed = true; // Simula confirmación para avanzar en la depuración

                        if (!confirmed) return; 

                        btn.disabled = true;
                        btn.textContent = 'Borrando...';
                        try {
                            const resp = await fetch('delete_document.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: `id=${encodeURIComponent(id)}&usuario=${encodeURIComponent(loggedUser)}`
                            });
                            const data = await resp.json();
                            if (data.success) {
                                btn.parentElement.remove();
                            } else {
                                // Reemplazando alert() con showMessage() y console.error()
                                showMessage('Error: ' + (data.error || 'No se pudo borrar.'), 'error');
                                console.error('Error al borrar documento:', data.error || 'No se pudo borrar.');
                            }
                        } catch (err) {
                            // Reemplazando alert() con showMessage() y console.error()
                            showMessage('Error: ' + err.message, 'error');
                            console.error('Error al borrar documento (catch):', err.message);
                        }
                    });
                });
            }
        } catch (err) {
            docsList.innerHTML = '<div class="text-red-400">' + err.message + '</div>';
        } finally {
            showDocsBtn.disabled = false;
            showDocsBtn.textContent = 'Ver mis documentos';
        }
    });
}

setInterval(() => {
    if (selectedFile) {
        summarizeButton.classList.add('animate-bounce-slow');
        setTimeout(() => {
            summarizeButton.classList.remove('animate-bounce-slow');
        }, 700);
    }
}, 10000);

// Animación de color para ambos títulos si existen
const mainTitle = document.getElementById('mainTitle');
const loginTitle = document.getElementById('loginTitle');
const titleColors = [
    'text-blue-500',
    'text-red-500',
    'text-green-500',
    'text-yellow-400',
    'text-purple-400',
    'text-pink-400',
    'text-cyan-400',
    'text-lime-400'
];
let colorIndex = 0;
setInterval(() => {
    if (mainTitle) {
        mainTitle.classList.remove(...titleColors);
        mainTitle.classList.add(titleColors[colorIndex]);
    }
    if (loginTitle) {
        loginTitle.classList.remove(...titleColors);
        loginTitle.classList.add(titleColors[colorIndex]);
    }
    colorIndex = (colorIndex + 1) % titleColors.length;
}, 2500);
