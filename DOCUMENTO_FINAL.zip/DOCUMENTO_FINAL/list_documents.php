<?php

require_once 'config.php';

header('Content-Type: application/json');

$response = [
    'success' => false,
    'data' => [],
    'message' => ''
];

try {
    if (!$conn || $conn->connect_error) {
        http_response_code(500);
        throw new Exception("Error de conexi��n a la base de datos. " . ($conn->connect_error ?? ''));
    }

    if (!isset($_GET['usuario'])) {
        http_response_code(400);
        throw new Exception('Falta el par��metro de usuario.');
    }
    $usuario = $_GET['usuario'];

    $stmt = $conn->prepare('SELECT id, nombre_original, nombre_archivo, fecha, permiso, ruta FROM documentos WHERE usuario = ? ORDER BY fecha DESC');

    if ($stmt === false) {
        throw new Exception("Error al preparar la consulta SQL: " . $conn->error);
    }

    $stmt->bind_param('s', $usuario);

    $stmt->execute();

    // Vincula las columnas de resultado a variables PHP (alternativa a get_result())
    $stmt->bind_result($id, $nombre_original, $nombre_archivo, $fecha, $permiso, $ruta);

    // Recorre los resultados fila por fila
    while ($stmt->fetch()) {
        $response['data'][] = [
            'id' => $id,
            'nombre_original' => $nombre_original,
            'nombre_archivo' => $nombre_archivo,
            'fecha' => $fecha,
            'permiso' => $permiso,
            'ruta' => $ruta
        ];
    }

    if (count($response['data']) > 0) {
        $response['success'] = true;
        $response['message'] = 'Documentos obtenidos exitosamente.';
    } else {
        $response['success'] = true;
        $response['message'] = 'No se encontraron documentos para el usuario ' . $usuario . '.';
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = 'Error en el servidor: ' . $e->getMessage();
    error_log("Error en list_documents.php: " . $e->getMessage());
} finally {
    if (isset($stmt) && $stmt !== false) {
        $stmt->close();
    }
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);

?>
