<?php
header('Content-Type: application/json');

require_once 'config.php';

$uploadDir = __DIR__ . '/documentos/';

$response = ['success' => false, 'error' => ''];

try {
    if (!$conn || $conn->connect_error) {
        http_response_code(500);
        throw new Exception('Error de conexión a la base de datos.');
    }

    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) {
            http_response_code(500);
            throw new Exception('No se pudo crear la carpeta de subida de documentos.');
        }
    }

    if (!isset($_FILES['file']) || !isset($_POST['usuario'])) {
        http_response_code(400);
        throw new Exception('Faltan datos requeridos (archivo o usuario).');
    }

    $usuario = $conn->real_escape_string($_POST['usuario']);
    $permiso = isset($_POST['permiso']) ? $conn->real_escape_string($_POST['permiso']) : 'privado';
    $nombreOriginal = basename($_FILES['file']['name']);

    $nombreArchivo = uniqid('doc_') . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $nombreOriginal);
    $rutaArchivo = $uploadDir . $nombreArchivo;

    date_default_timezone_set('America/Mexico_City');
    $fecha = date('Y-m-d H:i:s');

    if (move_uploaded_file($_FILES['file']['tmp_name'], $rutaArchivo)) {
        $sql = "INSERT INTO documentos (nombre_archivo, nombre_original, usuario, fecha, permiso, ruta) VALUES (?,?,?,?,?,?)";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            http_response_code(500);
            throw new Exception('Error al preparar la consulta SQL: ' . $conn->error);
        }

        $stmt->bind_param('ssssss', $nombreArchivo, $nombreOriginal, $usuario, $fecha, $permiso, $rutaArchivo);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Archivo subido y registrado exitosamente.';
            $response['archivo'] = $nombreArchivo;
            $response['ruta'] = $rutaArchivo;
        } else {
            http_response_code(500);
            if (file_exists($rutaArchivo)) {
                unlink($rutaArchivo);
            }
            throw new Exception('Error al registrar el documento en la base de datos: ' . $stmt->error);
        }
        $stmt->close();
    } else {
        http_response_code(500);
        throw new Exception('Error al subir el archivo al servidor.');
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['error'] = $e->getMessage();
    error_log("Error en upload.php: " . $e->getMessage());
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);

?>
